from unittest import TestSuite, TextTestRunner
from gui.basictestcases import BasicTestCases
from pyunitperf.LoadTest import LoadTest
from pyunitperf.TimedTest import TimedTest


class WebLoadSuite:
    def testLoginAndTopNavLinks(self):
        users = 10
        maxElapsedTimeInSec = 5
        #Create the actual tests
        testCase = BasicTestCases("testPages")
        #Wrap the tests inside a LoadTest
        loadTest = LoadTest(testCase, users)
        #Wrap LoadTest inside a TimedTest with max time allowed
        timedTest = TimedTest(loadTest, maxElapsedTimeInSec)
        return timedTest


    def suite(self):
        s = TestSuite()
        s.addTest(self.testLoginAndTopNavLinks())
        return s


if __name__ == "__main__":
    TextTestRunner(verbosity=1).run(WebLoadSuite().suite())

