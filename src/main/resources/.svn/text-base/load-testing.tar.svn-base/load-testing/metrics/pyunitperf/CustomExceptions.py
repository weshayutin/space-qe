"""
Port of jUnitPerf to Python
 **************************************
 * Ported to Python by Grig Gheorghiu *
 **************************************
"""

class IllegalArgumentException(Exception):
    pass
    
class AssertionFailedError(Exception):
    pass
    
    