import os
from unittest import TestSuite, TextTestRunner
from client.clienttests import BasicTestCases
from pyunitperf.Test import Test
from pyunitperf.loadtestset import LoadTestSet
from pyunitperf.TimedTest import TimedTest
from pyunitperf.ThreadedTestGroup import ThreadedTestGroup
from pyunitperf.ThreadedTest import ThreadedTest
from lib.xmlrpcclient import XmlRpcClient
from lib.RHNClient import get_name_stub
from random import randint
import copy

class ClientLoadSuite:
    
    def testThreaded(self):
        """ 
        Simple test just for debugging this setup.
        """
        users = 10
        maxElapsedTimeInSec = 999
        #Create the actual tests
        from client.threadtest import ThreadTest
        testCase = ThreadTest("testSimple")
        #Wrap the tests inside a LoadTest
        loadTest = LoadTestSet(testCase, users)
        #Wrap LoadTest inside a TimedTest with max time allowed
        timedTest = TimedTest(loadTest, maxElapsedTimeInSec)
        return timedTest
        
    
    def testRegister(self, test_id):
        """
        Register 10 clients.  The clients registered here are used in tests
        below.
        """
        users = 10
        maxElapsedTimeInSec = 999
        #Create the actual tests
        testCase = BasicTestCases("testRegister", test_id)
        #Wrap the tests inside a LoadTest
        loadTest = LoadTestSet(testCase, users)
        #Wrap LoadTest inside a TimedTest with max time allowed
        timedTest = TimedTest(loadTest, maxElapsedTimeInSec)
        return timedTest
    
    def testUpdatePackages(self, test_id):
        users = 1
        maxElapsedTimeInSec = 999
        testCase = BasicTestCases("testUpdatePackages", test_id)
        loadTest = LoadTestSet(testCase, users)
        timedTest = TimedTest(loadTest, maxElapsedTimeInSec)
        return timedTest

    def testRhnCheck(self, test_id):
        users = 10
        maxElapsedTimeInSec = 999
        testCase = BasicTestCases("testRhnCheck", test_id)
        loadTest = LoadTestSet(testCase, users)
        timedTest = TimedTest(loadTest, maxElapsedTimeInSec)
        return timedTest
        
    def testErrataUpdate(self, test_id):
        users = 20
        maxElapsedTimeInSec = 999
        testCase = BasicTestCases("testErrataUpdate", test_id)
        loadTest = LoadTestSet(testCase, users)
        timedTest = TimedTest(loadTest, maxElapsedTimeInSec)
        return timedTest
    
    def cleanup(self):
        ## Delete all the test systems this suite created.
        ## This can take a while depending on how many systems we 
        ## created during the tests.
        #print "SID: " + c.getSystemId()
        #sids = int(c.getSystemId())
        client = XmlRpcClient()
        session_key = client.session_key
        name = get_name_stub()
        systems = client.get_client().system.searchByName(session_key,\
            name + '*')
        sids = []
        for system in systems:
            print "Deleting: %s" % system['id']
            sids.append(system['id'])
            
        client.get_client().system.deleteSystems(session_key, sids)
        os.popen4("rm  *.id")
        os.popen4("rm  *.packs")
        
    def suite(self):
        s = TestSuite()
        test_id = randint(0, 100000)
        s.addTest(self.testRegister(test_id))
        #s.addTest(self.testErrataUpdatet(test_id))
        #s.addTest(self.testUpdatePackages(test_id))
        s.addTest(self.testRhnCheck(test_id))
        return s


if __name__ == "__main__":
    cls = ClientLoadSuite()
    TextTestRunner(verbosity=1).run(cls.suite())
    cls.cleanup()

