from unittest import TestCase
import time
from random import randint

class ThreadTest (TestCase):
    
    def __init__(self, name):
        TestCase.__init__(self, name)
        self.id = str(randint(1,1000))  
        
    def testSimple(self):
        print "Sleeping : %s" % self.id
        time.sleep(1.0)
        print "slept    : %s" % self.id