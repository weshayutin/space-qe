from pyunitperf.LoadTest import LoadTest
from pyunitperf.ThreadedTest import ThreadedTest
from random import randint
import copy

class LoadTestSet(LoadTest):
    """
    This extends LoadTest to ensure that we are running actual independant
    test instances.  This is useful if your unit tests contain some notion of
    state.  General unit tests should be stateless but sometimes its useful 
    todo so. 
    """ 
    def __init__(self, test, users):
        LoadTest.__init__(self, test, users)
        self.tests = []
        for i in range(users):
            copied = copy.deepcopy(test)
            copied.local_id = str(copied.local_id) + "_" + str(i)
            tt = ThreadedTest(copied, self.group, self.barrier)
            self.tests.append(tt)

    def run(self, result):
        """
         * Runs the test.
         *
         * @param result Test result.
        """
        self.group.setTestResult(result)
        i = 0
        for t in self.tests:
            print "Running: " + str(i) 
            t.run(result)
            i = i + 1
        
        self.waitForTestCompletion()
                    
