from os.path import expanduser, exists
from unittest import TestCase, TestSuite, TextTestRunner, makeSuite
from rhnsatclienttest import RhnSatClientTest
import sys, os
sys.path.insert(0, "../")
from lib.RHNClient import Client
from lib.xmlrpcclient import XmlRpcClient
from random import randint

class BasicTestCases(RhnSatClientTest):

    def __init__(self, name, local_id):
        RhnSatClientTest.__init__(self, name)
        print "Localid: " + str(local_id)
        self.local_id = local_id

    def testRegister(self):
        c = Client(self.testdir, self.local_id, 0, self.SAT_HOST, \
                   self.SAT_LOGIN, self.SAT_PASSWORD)
        c.run(1)
        print "Register Done."

    def testUpdatePackages(self):
        ## Create a client with 10 packages to update.
        c = Client(self.testdir,  self.local_id, 10, self.SAT_HOST, \
                   self.SAT_LOGIN, self.SAT_PASSWORD)
        c.run(1)

    def testErrataUpdate(self):
        c = Client(self.testdir,  self.local_id, 0, self.SAT_HOST, \
                   self.SAT_LOGIN, self.SAT_PASSWORD)
        c.run(1)
        
        # Lets schedule some errata updates
        client = XmlRpcClient()
        session_key = client.session_key
        sid = int(c.getActualSystemId())
        errata = client.get_client().system.getRelevantErrata(session_key, sid)
        # applyErrata
        eids = []
        for i in range(10):
            eids.append(int(errata[i]['id']))
            
        client.get_client().system.applyErrata(session_key, sid, eids)
        #now that errata is applied, lets rhn_check
        c.run(1)
        print "errataupdate"

    def testRhnCheck(self):
        ## This test relies on the previously registered systems 
        c = Client(self.testdir,  self.local_id, 0, self.SAT_HOST, \
                   self.SAT_LOGIN, self.SAT_PASSWORD)
        c.run(1)
        print "RhnCheck"

# If you want to run this test on its own
if __name__ == "__main__":
    example = BasicTestCases("testRegister")
    runner = TextTestRunner()
    runner.run(example.suite())
    