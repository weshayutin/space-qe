
from os.path import expanduser, exists
from unittest import TestCase, TestSuite, TextTestRunner, makeSuite
from rhnsatwebuitest import RhnSatWebUITest

class BasicTestCases(RhnSatWebUITest):

    def __init__(self, name):
        RhnSatWebUITest.__init__(self, name)

    def testPages(self):
        self.hitPage("/rhn/YourRhn.do")
        self.hitPage("/rhn/errata/Overview.do")



# If you want to run this test on its own
if __name__ == "__main__":
    example = LoginTestCase("testPages")
    runner = TextTestRunner()
    runner.run(example.suite())
    