
from os.path import expanduser, exists
from ConfigParser import ConfigParser
from unittest import TestCase, TestSuite, TextTestRunner, makeSuite
import time, urllib2, cookielib


class RhnSatWebUITest(TestCase):

    def __init__(self, name):
        TestCase.__init__(self, name)
        cfg = ConfigParser()
        # see ./setup.cfg for the server/uname/pass we use in these tests
        cfg.read('setup.cfg')
        self.host = cfg.defaults()['server']
        self.username = cfg.defaults()['username']
        self.password = cfg.defaults()['password']
        self.opener = self.getUrlOpener()

    def setUp(self):
        pass

    def tearDown(self):
        pass
    
    def hitPage(self, url):
        response = self.opener.open("https://%s/%s" % (self.host, url))
        contents = response.read()
        index = contents.find("Please Sign In")
        # If this fails it means we aren't logged in.
        assert (contents.find("Please Sign In") == -1), "Not Logged in!!" 
        print "."
        
    def suite(self):
        return makeSuite(self.__class__)

    def getUrlOpener(self):
        cookieFile =  expanduser("~/.pyload_cookie")
        cj = cookielib.MozillaCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        data = "username=" + self.username + "&password=" + self.password
        print "host: ", self.host
        opener.open("https://%s/rhn/LoginSubmit.do" % self.host, data=data)
        cj.save(cookieFile)
        return opener


