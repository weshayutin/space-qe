#!/usr/bin/env python

from unittest import TestCase
from ConfigParser import ConfigParser
from random import shuffle
import os

class RhnSatClientTest (TestCase):
    
    def __init__(self, name):
        TestCase.__init__(self, name)
        cfg = ConfigParser()
        cfg.read('setup.cfg')
        # Satellite to test against:
        self.SAT_HOST = cfg.defaults()['server']
        self.SAT_LOGIN = cfg.defaults()['username']
        self.SAT_PASSWORD = cfg.defaults()['password']
        self.testdir = "./"
        
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def random_string(self):
        letters = 'abcdefghijklmnopqrstuvwxyz'
        l = list(letters)
        for i in range(5):
            shuffle(l)
        ret = ''
        for c in l:
            ret += c
        return ret
