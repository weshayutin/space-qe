#!/usr/bin/python
import os
import string
import sys
import HttpGetSource
import random
from rhn import rpclib
from util import find

sys.path.insert(0, "/usr/share/rhn/")
from up2date_client import up2dateAuth
from rhn import rpclib
from up2date_client import rpcServer
from up2date_client import up2dateUtils
import socket


def get_name_stub():
    return socket.gethostbyaddr(socket.gethostname())[0] + "-fake-"

email = "sdjkfj@example.com"
os_release = "4AS"
arch = "i386"
release_name = ""
profileFile = "rhel-i386-as-4"
channel = "rhel-i386-as-4"
nameStub = get_name_stub()
deps = ["kernel", "xorg-x11", "librt.so.1"]
spoof_arch = "i386"


def main(): 
    clnt = Client(sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4], sys.argv[5], sys.argv[6])
    clnt.run(sys.argv[7])
             

class Client :
    
    def __init__(self, sid_dir, id, num_packages, server, user, passw):
        self.sidDir = sid_dir
        self.id = id
        self.server_url = "http://" + server + "/XMLRPC"
        self.user = user
        self.passwd = passw
        self.verbose = 1
        self.num_packages = num_packages
        self.xmlrpcClient = None
        self.package_profile = None

        
        
    
    def run(self, run_check):
        self.xmlrpcClient = self._connect()

        if not os.path.exists(self.sidDir + "/" + str(self.id) + ".id"): 
            self.register()
            
        self.login = self.xmlrpcClient.up2date.login(self._get_system_id())     
        self.getClient = self._connect_get()   
        
        if self.num_packages > 0 :
            self.runUpdate( self.num_packages)
        if run_check:
            self.rhnCheck()

    
    def register(self) :
        print "registering" + str(self.id)
        
        data = {
            'username'  : self.user,
            'password'  : self.passwd,
            'email'     : email,
            'os_release': os_release,
            'architecture': arch,
            'profile_name': nameStub + str(self.id),
            'rhnuuid'   : '-ENOBEER',
            'uuid'      : '-ENOFOOD',
            'packages'  : self.get_package_profile(),
            'release_name'  : release_name,
            'os': "redhat-release"
        }
        self._systemid_data = self.xmlrpcClient.registration.new_system(data)
        open(self.sidDir + "/" + str(self.id) + ".id", "w+").write(self._systemid_data)
        return
    
    
    def runUpdate(self,  numOfPacks) :
        
        channelObj = self._get_channel()
        
        packs = self._list_packages(channelObj)
        obs = self._list_obsoletes(channelObj)
        resol = self._solve_deps(deps)
        
        packageList = []
        
        for i in range (0, numOfPacks) :
            # packageInfo = random.choice(packs)
            packageInfo = packs[i]
            packs.remove(packageInfo)
            print "working with package " + packageInfo[0]
            packageHdr = self._get_header(packageInfo)
            package = self._get_package(packageInfo)
            packageList.append(packageInfo)
        print "adding packages"
        self.xmlrpcClient.registration.add_packages(self._get_system_id(), packageList)

        return    
    
    def getActualSystemId(self):
        idxml = self._get_system_id()
        idx = idxml.index("<value><string>ID-")
        sid = idxml[idx+18:idx+28] 
        return sid
    
    #returns 0 if no action, 1 if it completed the action
    def rhnCheck(self):
        functions = {
                     "errata.update": self._errata_update_check                    
                     }
        
        action = self._get_queue()
        if action == "" or action == {}:
            return 0
        
        print action
        
        version = action['version']
        action_id = action['id']
        data = action['action']
        
        parser, decoder = rpclib.getparser()
        parser.feed(data)
        parser.close()
        params = decoder.close()
        method = decoder.getmethodname()

        ret = functions[method](params)
        
        if ret == 0:
            self._queue_submit(action_id, 0, "success")
        else:
            self._queue_submit(action_id, 1 , "error")
            
        return self.rhnCheck()
    
    def _connect(self):
        if self.xmlrpcClient is None:
            if self.verbose >= 1:
                print "Connecting to %s" % self.server_url
            self.xmlrpcClient = rpclib.Server(self.server_url)
        return self.xmlrpcClient
    
    def _connect_get(self,):
        server= rpcServer.RetryGETServer(self.server_url,
                                     headers = self.login)
        server.add_header("X-Up2date-Version", up2dateUtils.version())
        return HttpGetSource.HttpGetSource(server, "/tmp/", self.login)
        
    def get_package_profile(self):
        if self.package_profile != None:
            return self.package_profile
        
        pack_path = self.sidDir + str(self.id) + ".packs"
        if os.path.exists(pack_path):
            self.package_profile =  self._profile_from_file(pack_path) 
        else:
            self.package_profile = self._profile_from_file(profileFile) 
        
        return self.package_profile
    
    
    #read package profile from a file, pulled from up2date_client libs
    def _profile_from_file(self, profile_file):
        print "Using package profile from", profile_file        
        found = find(profile_file)
        if found is None:
            found = find("lib/" + profile_file)
        profile_file = found
        ret = []
        f = open(profile_file)
        #upload_package_arches = self._upload_package_arches()
        while 1:
            buffer = f.readline()
            if not buffer:
                break
            buffer = string.strip(buffer)

            arr = string.split(buffer, " ", 4)
            if len(arr) < 4:
                print "Malformed entry in file %s; `%s'" % (profile_file,
                    buffer)
                continue
            if arr[3] == '(none)':
                arr[3] = ''
            ret.append(arr[:5])
        f.close()
        return ret

    def _write_profile(self):
        f = open(self.sidDir + '/' + str(self.id) + ".packs", "w+")
        for i in self.package_profile:
            f.write(i[0] + " ")
            f.write(i[1] + " ")
            f.write(i[2] + " ")
            if i[3] == '':
                f.write("(none) ")
            else:
                f.write(i[3])
            if len(i) > 4:
                f.write(i[4])            
            f.write("\n")           
        f.close()
        return


    def _get_channel(self):
        return {'label' : channel , 'version' : self.login['X-RHN-Auth-Channels'][0][1]}

    #read in the system id file
    def _get_system_id(self):
         f = open(self.sidDir + "/" + str(self.id) + ".id", "r")
         return f.read()


     ###
     # xmlrpc call wrappers (also handles package addition removal)
     ###
    def _get_header(self, packageInfo):
        return self.getClient.getHeader(packageInfo)
    
    def _get_package(self, packageInfo):
        return self.getClient.getPackage(packageInfo)
    
    def _list_packages(self, channel):
        return self.getClient.listPackages(channel)
    
    def _list_channels(self):
        return self.xmlrpcClient.up2date.listChannels(self._get_system_id())
    
    def _list_all_packages(self, channel):
        return self.getClient.listAllPackages(channel)        
    
    def _list_obsoletes(self, channel):
        return self.getClient.getObsoletes(channel)
        
    def _solve_deps(self, deps):
        return self.xmlrpcClient.up2date.solvedep(self._get_system_id(), deps)
    
    def _errata_get_info(self, errataId):
        return self.xmlrpcClient.errata.getErrataInfo(self._get_system_id(), errataId)        
    
    def _get_queue(self):
        return self.xmlrpcClient.queue.get(self._get_system_id(), 2)
    
    def _remove_packages(self, list):
        for pack in list:
            try:
                self.package_profile.remove(pack)
            except:
                print "Couldn't remove " + str(pack) + " from " + self.id
        try:
            return self.xmlrpcClient.registration.delete_packages(self._get_system_id(), list)
        except:
            print "Couldn't remove " + str(list) + " from " + self.id
            return ""
    
    def _add_packages(self, list):
        for pack in list:
            pack.append(spoof_arch)
            self.package_profile.append(pack)
        return self.xmlrpcClient.registration.add_packages(self._get_system_id(), list)    
    
    def _queue_submit(self, id, code, message):
        return self.xmlrpcClient.queue.submit(self._get_system_id(), id, code, message)
    
    def _errata_update_check(self, params):       
        
        for errata in params[0]:
            info = self._errata_get_info(errata)
            allPackList = self._list_all_packages(self._get_channel())
            self._list_packages(self._get_channel())
            self._list_obsoletes(self._get_channel())
            newList = info
            for package in info:
                fullPack = self._find_pack_in_list(package, allPackList)
                self._get_header(fullPack)
                self._get_package(fullPack)
            
            self._list_channels()
            
            #remove package from the profile
            packagesToRemove = []
            for i in info:
                packagesToRemove.append(self._find_pack_in_list_by_name(i, self.get_package_profile()))
            print packagesToRemove
            self._remove_packages(packagesToRemove)
            self._add_packages(info)
            self._write_profile()

        return 0
    
    ##incomplete
    def _update_packages_check(self, packages):
        for pack in packages[0]:
            print pack
            #self._get_header(pack)
            #self._get_package(pack)
        return
         
    def _find_pack_in_list(self, pack, list):
        for item in list:
            if pack[0] == item[0] and pack[1] == item[1] and pack[2] == item[2]:
                return item
        return None
    
    def _find_pack_in_list_by_name(self, pack, list):
        for item in list:
            if pack[0] == item[0]:
                return item
        return None    

if __name__ == "__main__":
    main()      
