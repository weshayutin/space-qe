#!/usr/bin/python

#Ripped from the up2date_client package
import os
import sys

#import rpm
sys.path.append("/usr/share/rhn/")
#import genericRepo
from up2date_client import rpmSource
#from up2date_client import rpmSourceUtils
#from up2date_client import rhnChannel
#from up2date_client import repoDirector
#from up2date_client import up2dateAuth
#from up2date_client import rpcServer
#from up2date_client import config
#from up2date_client import up2dateUtils
#from up2date_client import up2dateErrors
from up2date_client import rpmUtils
#from up2date_client import rpcServer
#import genericSolveDep

#from rhn import rpclib, xmlrpclib



class HttpGetSource(rpmSource.PackageSource):

    def __init__(self, server, storageDir,
                 loginInfo, cacheObject = None):
        self.s = server
        self.storageDir = storageDir
        rpmSource.PackageSource.__init__(self, cacheObject = cacheObject)



    def _readFD(self, fd, filename, fileflags, pdLen, status, startpoint=0):
        # Open the storage file
        f = open(filename, fileflags)

        # seek to the start point, overwriting the last bits
        if pdLen and status != 200:
            f.seek(startpoint)

        while 1:
            chunk = fd.read(rpmSource.BUFFER_SIZE)
            l = len(chunk)
            if not l:
                break
            f.write(chunk)
            
        f.flush()
        # Rewind
        f.seek(0, 0)
        return f.read()
            

    def getHeader(self, package, msgCallback = None, progressCallback = None):
        hdr = None
        # package list format
        # 0        1        3       4     5     6      7
        # name, version, release, epoch, arch, size, channel

        filename = "%s-%s-%s.%s.hdr" % (package[0], package[1], package[2],
            package[4])
        channel = package[6]

        filePath = "%s/%s" % (self.storageDir, filename)
        self.s.set_progress_callback(progressCallback,rpmSource.BUFFER_SIZE )
        
        fd = self.s.getPackageHeader(channel, filename)

        pkgname = "%s-%s-%s" % (package[0], package[1], package[2])
        if msgCallback:
            msgCallback(filename)

        buffer = fd.read()
        fd.close()             
            
        hdr = rpmUtils.readHeaderBlob(buffer)
        return hdr

    
    def getPackage(self, package, msgCallback = None, progressCallback = None):
 #       print "gh 232423423423"
        filename = "%s-%s-%s.%s.rpm" % (package[0], package[1], package[2],
                                        package[4])

        partialDownloadPath = "%s/%s" % (self.storageDir, filename)
        if os.access(partialDownloadPath, os.R_OK):
            pdLen = os.stat(partialDownloadPath)[6]
        else:
           pdLen = None

        self.s.set_transport_flags(allow_partial_content=1)

        startpoint = 0
        if pdLen:
            size = package[5]
            # trim off the last kb since it's more likely to
            # be trash on a reget
            startpoint = long(pdLen) - 1024
            
        channel = package[6]

        if msgCallback:
            msgCallback(filename)

#        print progressCallback
#        print "\nself.s", self.s, progressCallback
        #self.s.set_progress_callback(progressCallback, rpmSource.BUFFER_SIZE )
        filePath = "%s/%s" % (self.storageDir, filename)
        if pdLen:
            fd = self.s.getPackage(channel, filename, offset=startpoint)
        else:
            fd = self.s.getPackage(channel, filename)
         
        if pdLen:
            fflag = "r+"
        else:
            fflag = "w+"

        status = self.s.get_response_status()
        #f = open(filePath, fflag)
        #if pdLen and status != 200:
        #    f.seek(startpoint)
       # f.write(fd.read())
        #f.flush()
        #f.close()

#        self._readFD(fd,filePath,fflag, pdLen, status, startpoint)
        


        
        buffer = fd.read()    
        fd.close()
        return buffer

    
    def getPackageSource(self, channel, package,
                         msgCallback = None, progressCallback = None):
        filename = package

        filePath = "%s/%s" % (self.storageDir, filename)
        self.s.set_progress_callback(progressCallback,rpmSource.BUFFER_SIZE )
        fd = self.s.getPackageSource(channel['label'], filename)

        if msgCallback:
            msgCallback(package)

        channel = package[6]

        startpoint = 0
        pdLen = None
        fflag = "w+"
        status = self.s.get_response_status()
        buffer = self._readFD(fd, filePath, fflag, pdLen, status, startpoint)
        fd.close()
        return buffer
        

    def listPackages(self, channel, dmsgCallback = None, progressCallback = None):
        list = self.s.listPackages(channel['label'], channel['version'])
        return list

    def listAllPackages(self, channel,
                     msgCallback = None, progressCallback = None):
        filePath = "%s/%s-all.%s" % (self.storageDir, channel['label'], channel['version'])
        # a glob used to find the old versions to cleanup
        globPattern = "%s/%s-all.*" % (self.storageDir, channel['label'])

        self.s.set_progress_callback(progressCallback)

        # FIXME: I still dont like the seemingly arbitrary fact that this
        # method returns a python structure, and all the other gets return
        # a file descriptor.
        list = self.s.listAllPackages(channel['label'], channel['version'])
        

        # do something to save it to disk.
        #rpmSourceUtils.saveListToDisk(list, filePath,globPattern)

        return list


    def getObsoletes(self, channel,
                     msgCallback = None, progressCallback = None):
        filePath = "%s/%s-obsoletes.%s" % (self.storageDir,
                                           channel['label'], channel['version'])
        globPattern = "%s/%s-obsoletes.*" % (self.storageDir,
                                            channel['label'])
        self.s.set_progress_callback(progressCallback)
        obsoletes = self.s.getObsoletes(channel['label'], channel['version'])
        
       
        #rpmSourceUtils.saveListToDisk(obsoletes, filePath, globPattern)
        return obsoletes