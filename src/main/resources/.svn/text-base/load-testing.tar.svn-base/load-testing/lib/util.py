#!/usr/bin/env python
import sys, os

class Error(Exception): pass

def _find(path, matchFunc=os.path.isfile):
    for dirname in sys.path:
        candidate = os.path.join(dirname, path)
        if matchFunc(candidate):
            return candidate
    return None
    
def find(path):
    return _find(path)

def findDir(path):
    return _find(path, matchFunc=os.path.isdir)