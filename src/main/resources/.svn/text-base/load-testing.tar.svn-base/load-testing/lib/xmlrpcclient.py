import xmlrpclib
from ConfigParser import ConfigParser

class XmlRpcClient(object):
    
    def __init__(self):
        cfg = ConfigParser()
        cfg.read('setup.cfg')
        # Satellite to test against:
        self.SAT_HOST = cfg.defaults()['server']
        self.SAT_API_URL = "http://%s/rpc/api" % self.SAT_HOST
        self.SAT_LOGIN = cfg.defaults()['username']
        self.SAT_PASSWORD = cfg.defaults()['password']
        # One xmlrpc client to be used throughout the tests:
        self.xmlrpcclient = xmlrpclib.Server(self.SAT_API_URL, verbose=0)
        self.session_key = self.xmlrpcclient.auth.login(self.SAT_LOGIN, self.SAT_PASSWORD)

    def xmlrpclogout(self, session_key):
        self.xmlrpcclient.auth.logout(session_key)

    def get_client(self):
        return self.xmlrpcclient