#!/usr/bin/python
import commands
import sys


debug = 0
server = "rlx-2-14.rhndev.redhat.com"

run_register_test = 1
run_update_test = 0



def main():
        
    num_packs = 10
    
    update_tests = {
             10: [1, 3, 5, 7, 10],
             50: [5, 10, 15, 20, 25],
             100: [5, 10, 20, 50]
             }
    
    register_tests = {
             50: [5, 10, 15, 20, 25]
             }                   
    
    update_results = {}
    register_results = {}
    
    
    if run_register_test:  
        #run register test
        for events,array in register_tests.iteritems():
            register_results[events] = {}
            for threads in array:
                command = "./Threadpool.py -q -s " + str(events) + " -t " + str(threads) + " -c -u " + server
                register_results[events][threads] = run_com(command)  
        
    if run_update_test:
        #run update test
        for events,array in update_tests.iteritems():
            update_results[events] = {}
            for threads in array:
                command = "./Threadpool.py -q -s " + str(events) + " -t " + str(threads) + \
                        " -p " + str(num_packs) + " -u " + server
                update_results[events][threads] = run_com(command)


    f=open('output.csv', 'w')
    f.write("Registration test(s):\n")
    record_results(f, register_results)
    f.write("Update tests:\n")
    record_results(f, update_results)
    f.close()
    
    
def run_com(command):    
    if debug:
        print command
        return 0
    else:
        return commands.getoutput(command)
    
def record_results(file, array): 
    for events,result in array.iteritems():
        #record the number of events
        file.write("Systems: " + str(events) + "\n")
        
        #record how many threads
        for threads in result:
            file.write(str(threads) + ",")
        file.write("\n")
        
        #record the time        
        for threads in result:           
            file.write(str(array[events][threads]) + ",")        
        file.write("\n\n\n")
    
    
if __name__ == "__main__":
    main()       
    