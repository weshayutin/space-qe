#!/usr/bin/python


import threading
import time
import lib.RHNClient
import sys
import os
import popen2
import getopt



debug=0




class RegisterThread (threading.Thread):

    def __init__(self, startNum, endNum, packages, dir, server, rhnCheck):
        self.startNum = startNum
        self.endNum = endNum
        self.packages = packages
        self.sidDir = dir
        self.server = server
        self.check = rhnCheck
        threading.Thread.__init__ (self)

            
    def run (self):
        curr = 0;
        while curr + self.startNum <= self.endNum:
            #print "starting  " + str((self.startNum + curr))
            subproc = _runCom("lib/RHNClient.py " + 
                                    self.sidDir + " "+ 
                                    str((self.startNum + curr)) + " " + 
                                    str(self.packages) + " " +
                                    self.server['url']  + " " + 
                                    self.server['login'] + " " + 
                                    self.server['password'] + " " + 
                                    str(self.check))
            time.sleep(.01)
            if subproc and subproc.poll() == -1:
                    subproc.wait()
            #print "ending " + str((self.startNum + curr))
            curr = curr + 1
        return 
    





def main():
    
    ##Handle options parsing
    opt, arg = getopt.getopt(sys.argv[1:], "hkcqt:s:d:p:n:d:u:l:m:", 
                             ["help", "threads=", "systems=", "dir=", "num-packages=", "quiet", "clear", "rhncheck", "span"])
    
    threads = 0
    events = 0
    packages = 0
    dir = "/tmp/"
    quiet = None
    clear = None
    check = 0
    span=0
    
    server = {
              "url": "rlx-2-10.rhndev.redhat.com",
              "login": "admin",
              "password": "redhat"
              }
    
    for o, a in opt:
        if o in ("-h", "--help"):
            usage()
            sys.exit()
        elif o in ("-t", "--threads="):
            threads = int(a)
        elif o in ("-s", "--systems="):
            events = int(a)
        elif o in ("-n", "--num-packages"):
            packages = int(a)            
        elif o in ("-d", "--dir="):
            dir = a
        elif o in ("-u", "--url"):
            server['url'] = a
        elif o in ("-l", "--login"):
            server['login'] = a            
        elif o in ("-p", "--password"):
            server['password'] = a
        elif o in ("-q", "--quiet"):            
            quiet = True
        elif o in ("-c", "--clear"):            
            clear = True            
        elif o in ("-k", "--rhncheck"):            
            check = 1
        elif o in ("-m", "--span"):            
            span = int(a)
            


    if threads > 0 and span > 0:
        print "Warning: Ignoring thread count as time limit is imposed"
    elif threads==0 and span==0:
        print "Must specify at least one thread or a time span"
        sys.exit(1)

    if events == 0:
        print "Must have at least one system"
        sys.exit(1)
        
    if threads > events:
        threads = events
        
    if clear:
        delIds(dir, events);
                
    if not quiet:
        if span == 0:
            print "Threads: " + str(threads)
        else:
            print "Time limit: " + str(span) + " mins."
        print "Systems: " + str(events)
        print "Total Registrations Needed: " + str(countRegistrations(dir, events))
        print "Packages per system: " + str(packages)
        if check:
            print "Will run rhn_check on all systems"
    
    startTime = int(time.time())
    
    if span == 0:
        threaded_run(events, threads, packages, dir, server, check)
    else:
        span_run(events, packages, dir, server, check, span)


    end_time = int(time.time())
    if quiet:
        print str(end_time - startTime)
    else:
        print "Total Time: " + str((end_time-startTime)/60) + " min, " + str((end_time-startTime)%60) + " sec."




def span_run(events, packages, dir, server, check, span):
    sleep_time = float(span*60)/events
    
    thread_list = []     
    
    for x in xrange(events):
        thread = RegisterThread( x, x+1, packages, dir, server, check)
        thread_list.append(thread)
        thread.start()
        print "Sleeping " + str(sleep_time)
        time.sleep(sleep_time)    
    
    join_threads(thread_list)
    
    return


#run without a time span, so use threads
def threaded_run(events, threads, packages, dir, server, check ):
    
    #Spawn off threads with their assigned work load
    excess = events%threads 
    excessUsed = 0
    thread_list = []     
    
    for x in xrange(threads):
        if excess > excessUsed:
            #print x*(events/threads) + excessUsed, (x+1)*(events/threads) + excessUsed
            thread = RegisterThread( x*(events/threads) + excessUsed, (x+1)*(events/threads) + excessUsed, packages, dir, server, check)
            excessUsed = excessUsed + 1
        else:
            #print x*(events/threads) +excessUsed , (x+1)*(events/threads) - 1 + excessUsed
             thread = RegisterThread( x*(events/threads) +excessUsed , (x+1)*(events/threads) - 1 + excessUsed, packages, dir, server, check)
        thread_list.append(thread)
        thread.start()
        
    join_threads(thread_list)


def join_threads(list):
    for thread in list:
        if thread.isAlive():
            try: 
                thread.join()
            except:
                continue    


def countRegistrations(dir, num):
    count = 0
    for i in xrange(num):
        if not (os.path.exists(dir + "/" + str(i) + ".id")):
            count = count + 1
    return count

def _runCom(command):
    if debug:
        print command
        return None
    else: 
        return popen2.Popen3(command)
        
def usage():
    print "Required Arguments"
    print "-s, --systems=NUM_SYSTEMS\tNumber of systems to distribute across threads"
    print "\n"
    print "Optional arguments"
    print "-t, --threads=NUM_THREADS \tNumber of threads"    
    print "-k, --rhncheck\t\t\tRun rhn_check on set systems"
    print "-n, --num-packages=NUM_PACKS \tNumber of Packages to install on each system"
    print "-d, --dir=SYSID_DIR \t\tThe directory to hold the system ids in (Defaults to /tmp/)"
    print "-u, --url=SERVER_URL \t\tThe Server URL to use (Defaults to variable set in RHNClient.py)"
    print "-l, --login=LOGIN \t\tThe username to login to the server with (Defaults to admin)"
    print "-p, --password=PASSWORD\t\tThe password to login to the server with (Defaults to redhat)"
    print "-c, --clear \t\t\tIgnore any existing systemIds, and simply re-register the system"
    print "-m, --span=MINUTES \t\tThe time span (in minutes) you would like the events to occur in (Required if -t isn't passed)"
    print "-q, --quiet\t\t\tOnly print total time in seconds (useful to gather statistics)"
    print "-h, --help  \t\t\tPrint help"    


def delIds(dir, num):
    for i in xrange(num):
        id_path = dir + "/" + str(i) + ".id"
        pack_path = dir + "/" + str(i) + ".packs"
        if os.path.exists(id_path):    
            os.remove(id_path)
        if os.path.exists(pack_path):    
            os.remove(pack_path)        

if __name__ == "__main__":
    main()       
    
    